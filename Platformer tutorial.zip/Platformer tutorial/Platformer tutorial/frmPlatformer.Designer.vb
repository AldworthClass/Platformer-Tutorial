﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPlatformer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.imgPlayer = New System.Windows.Forms.PictureBox()
        Me.imgLava1 = New System.Windows.Forms.PictureBox()
        Me.imgGround2 = New System.Windows.Forms.PictureBox()
        Me.imgGround1 = New System.Windows.Forms.PictureBox()
        Me.tmrGravity = New System.Windows.Forms.Timer(Me.components)
        Me.tmrJump = New System.Windows.Forms.Timer(Me.components)
        Me.tmrLeft = New System.Windows.Forms.Timer(Me.components)
        Me.tmrRight = New System.Windows.Forms.Timer(Me.components)
        Me.imgPlatform2 = New System.Windows.Forms.PictureBox()
        Me.imgPlatform1 = New System.Windows.Forms.PictureBox()
        CType(Me.imgPlayer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgLava1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgGround2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgGround1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgPlatform2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgPlatform1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'imgPlayer
        '
        Me.imgPlayer.BackColor = System.Drawing.Color.Black
        Me.imgPlayer.Location = New System.Drawing.Point(113, 243)
        Me.imgPlayer.Name = "imgPlayer"
        Me.imgPlayer.Size = New System.Drawing.Size(34, 32)
        Me.imgPlayer.TabIndex = 0
        Me.imgPlayer.TabStop = False
        '
        'imgLava1
        '
        Me.imgLava1.BackColor = System.Drawing.Color.Red
        Me.imgLava1.Location = New System.Drawing.Point(371, 372)
        Me.imgLava1.Name = "imgLava1"
        Me.imgLava1.Size = New System.Drawing.Size(100, 50)
        Me.imgLava1.TabIndex = 1
        Me.imgLava1.TabStop = False
        '
        'imgGround2
        '
        Me.imgGround2.BackColor = System.Drawing.Color.Green
        Me.imgGround2.Location = New System.Drawing.Point(463, 361)
        Me.imgGround2.Name = "imgGround2"
        Me.imgGround2.Size = New System.Drawing.Size(182, 50)
        Me.imgGround2.TabIndex = 2
        Me.imgGround2.TabStop = False
        '
        'imgGround1
        '
        Me.imgGround1.BackColor = System.Drawing.Color.Green
        Me.imgGround1.Location = New System.Drawing.Point(0, 361)
        Me.imgGround1.Name = "imgGround1"
        Me.imgGround1.Size = New System.Drawing.Size(372, 50)
        Me.imgGround1.TabIndex = 3
        Me.imgGround1.TabStop = False
        '
        'tmrGravity
        '
        Me.tmrGravity.Enabled = True
        Me.tmrGravity.Interval = 25
        '
        'tmrJump
        '
        Me.tmrJump.Interval = 20
        '
        'tmrLeft
        '
        Me.tmrLeft.Interval = 25
        '
        'tmrRight
        '
        Me.tmrRight.Interval = 25
        '
        'imgPlatform2
        '
        Me.imgPlatform2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.imgPlatform2.Location = New System.Drawing.Point(113, 304)
        Me.imgPlatform2.Name = "imgPlatform2"
        Me.imgPlatform2.Size = New System.Drawing.Size(155, 22)
        Me.imgPlatform2.TabIndex = 4
        Me.imgPlatform2.TabStop = False
        '
        'imgPlatform1
        '
        Me.imgPlatform1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.imgPlatform1.Location = New System.Drawing.Point(297, 243)
        Me.imgPlatform1.Name = "imgPlatform1"
        Me.imgPlatform1.Size = New System.Drawing.Size(152, 22)
        Me.imgPlatform1.TabIndex = 5
        Me.imgPlatform1.TabStop = False
        '
        'frmPlatformer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(640, 405)
        Me.Controls.Add(Me.imgPlatform1)
        Me.Controls.Add(Me.imgPlatform2)
        Me.Controls.Add(Me.imgGround1)
        Me.Controls.Add(Me.imgGround2)
        Me.Controls.Add(Me.imgLava1)
        Me.Controls.Add(Me.imgPlayer)
        Me.Name = "frmPlatformer"
        Me.Text = "Platformer"
        CType(Me.imgPlayer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgLava1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgGround2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgGround1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgPlatform2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgPlatform1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents imgPlayer As System.Windows.Forms.PictureBox
    Friend WithEvents imgLava1 As System.Windows.Forms.PictureBox
    Friend WithEvents imgGround2 As System.Windows.Forms.PictureBox
    Friend WithEvents imgGround1 As System.Windows.Forms.PictureBox
    Friend WithEvents tmrGravity As System.Windows.Forms.Timer
    Friend WithEvents tmrJump As System.Windows.Forms.Timer
    Friend WithEvents tmrLeft As System.Windows.Forms.Timer
    Friend WithEvents tmrRight As System.Windows.Forms.Timer
    Friend WithEvents imgPlatform2 As System.Windows.Forms.PictureBox
    Friend WithEvents imgPlatform1 As System.Windows.Forms.PictureBox

End Class
