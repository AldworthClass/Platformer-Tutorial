﻿Public Class frmPlatformer
    Dim intVSpeed As Integer
    Dim intHSpeed As Integer
	'We can store platforms here
	Dim platforms As New List(Of PictureBox)
	'We can store our lava here
	Dim lavas As New List(Of PictureBox)
	Dim onGround As Boolean
    Dim intJumpCounter As Integer

    'Detects when keys are pressed
    Private Sub frmPlatformer_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Up Then
            'Only allows jumping if the player is on the ground
            If onGround Then
                onGround = False
                tmrGravity.Enabled = False
                tmrJump.Enabled = True
                intJumpCounter = 0
            End If
        ElseIf e.KeyCode = Keys.Right Then
            tmrRight.Enabled = True
        ElseIf e.KeyCode = Keys.Left Then
            tmrLeft.Enabled = True
        End If
    End Sub

    'Detects when keys are released
    Private Sub frmPlatformer_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.Up Then
            tmrJump.Enabled = False
            tmrGravity.Enabled = True
        ElseIf e.KeyCode = Keys.Right Then
            tmrRight.Enabled = False
        ElseIf e.KeyCode = Keys.Left Then
            'Disabling the 
            tmrLeft.Enabled = False
        End If
    End Sub

    Private Sub frmPlatformer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'These variables control how much the x and y coordinates are changed when any of the movement timers tick
        intVSpeed = 5
        intHSpeed = 3
		'Adds our platform PictureBoxes, and Lava Pictureboxes to Lists
		platforms.Add(imgGround1)
		platforms.Add(imgGround2)
		platforms.Add(imgPlatform1)
		platforms.Add(imgPlatform2)
		lavas.Add(imgLava1)
	End Sub

    Private Sub tmrGravity_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrGravity.Tick
        'We will start off by assuming that we can fall
        onGround = False
        'Iterates through all platforms
        For Each platform In platforms
            'Predicts where we will be if we fall, and sees if it will put us in a collision
            If New Rectangle(imgPlayer.Location.X, imgPlayer.Location.Y + intVSpeed, imgPlayer.Width, imgPlayer.Height).IntersectsWith(platform.Bounds) Then
                'A collision was detected so we locate our player right on top of platform
                imgPlayer.Top = platform.Top - imgPlayer.Height
                'We are not on the ground, and will not need to fall
                onGround = True
            End If
        Next
        'Checks to see whether we are on the ground
        If Not onGround Then
            'If we didn't land on a platform we can fall
            imgPlayer.Top += intVSpeed
        End If
        'Checks to see if we hot Lava and die
        deathDetectFall()
    End Sub

    Private Sub tmrJump_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrJump.Tick
        'We will use this so we know if we bump into the bottom of a platform
        Dim bolHitsPlatform As Boolean
        'Iterates through all platforms
        For Each platform In platforms
            'Predicts where we will be when we move our player up so, and checks to see if it will cause a collision
            If New Rectangle(imgPlayer.Location.X, imgPlayer.Location.Y - intVSpeed, imgPlayer.Width, imgPlayer.Height).IntersectsWith(platform.Bounds) Then
                'A collision was detected, so we put the top if our player right against the bottom of the platofrm
                imgPlayer.Top = platform.Bottom
                bolHitsPlatform = True
            End If
        Next
        intJumpCounter += 1
        'If we reach the peak of our jump, or hit the bottom of a platform, our jump is over, and gravity should be enabled
        If intJumpCounter >= 15 Or bolHitsPlatform Then
            tmrJump.Enabled = False
            tmrGravity.Enabled = True
        Else
            imgPlayer.Top -= intVSpeed
        End If

    End Sub

    Private Sub tmrLeft_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrLeft.Tick
        'This will tell us if we hit a platform's right side (because we are moving left)
        Dim bolHitPlatform As Boolean
        'Iterates through all platforms
        For Each platform In platforms
            'Predicts where we will be if we move left and looks for a collision
            If New Rectangle(imgPlayer.Location.X - intHSpeed, imgPlayer.Location.Y, imgPlayer.Width, imgPlayer.Height).IntersectsWith(platform.Bounds) Then
                'Since a collision was detected, our player is placed against the right side of the platform
                imgPlayer.Left = platform.Right
                bolHitPlatform = True
            End If
        Next
        'If there was no collision detected, we actually move
        If Not bolHitPlatform Then
            imgPlayer.Left -= intHSpeed
        End If
    End Sub

    Private Sub tmrRight_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrRight.Tick
        'This will tell us if we hit a platform's left side (because we are moving right)
        Dim bolHitPlatform As Boolean
        'Iterates through all platforms
        For Each platform In platforms
            'Predicts where we will be if we move right and looks for a collision
            If New Rectangle(imgPlayer.Location.X + intHSpeed, imgPlayer.Location.Y, imgPlayer.Width, imgPlayer.Height).IntersectsWith(platform.Bounds) Then
                'Since a collision was detected, our player is placed against the left side of the platform
                imgPlayer.Left = platform.Left - imgPlayer.Width
                bolHitPlatform = True
            End If
        Next
        'If there was no collision detected, we actually move
        If Not bolHitPlatform Then
            imgPlayer.Left += intHSpeed
        End If
    End Sub

    'This will determine whether player has colided with lava and dies and should be called every time gravity is applied
    'You can add a similar finction for hitting enemies, powerups etc. to be called at appropriate times
    Sub deathDetectFall()
        For Each lava In lavas
            If imgPlayer.Bounds.IntersectsWith(lava.Bounds) Then
                tmrGravity.Enabled = False
                tmrLeft.Enabled = False
                tmrRight.Enabled = False
                MsgBox("Your life has ended by natural selection, ensuring a stronger genepool in your absence.")
                Me.Close()
            End If
        Next
    End Sub

End Class
